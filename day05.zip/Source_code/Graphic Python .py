#!/usr/bin/env python
# coding: utf-8

# In[13]:


# This is a starting file of Python
# 그래픽을 간단하게 파이썬으로 구현해볼 예정입니다.  


# In[14]:


# 1. 필요한 패키지를 설치
# 2. 패키지를 사용 

from tkinter import *


# In[15]:


window = Tk()   # 윈도우 만들어주는 함수 


# In[16]:


window.title("my second window")


# In[17]:


window.geometry("800x600")


# In[18]:


window.mainloop()


# In[ ]:





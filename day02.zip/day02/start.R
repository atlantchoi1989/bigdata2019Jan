a <- 100 
b <- 200 

print(a + b) 
# 주석 (설명) 

# 프로그램 전체 제어문
# 1. 프로그램은 순차적으로 실행
# 2. 조건(보통반복문안에)
# 3. 반복 
# 데이터의 자료 구조 
# 데이터프레임 = 벡터(열) + 리스트(행)  

name <- c(1, 2, 3, 4, 5)
name[3] # 인덱스[] 사용  
print(name[3])

name[3] <- 333 
name 


name <- c("김지훈", "이유진", "박동현", "김민지")
name[4]
print(name[4])
name[4] <- "송민지" 
name 


str(name)   # 구조 
table(name)  # 요약 
class(name)    # 데이터의 타입
typeof(name)  # 데이터의 타입(상세) 



name <- c("김지훈", "이유진", "박동현", "송민지")
eng <- c(90, 80, 60, 70)
math <- c(50, 60, 100, 20)


# 자동완성(컨트롤 + 스페이스바, 탭(Tab))
midTerm <- data.frame(name, eng, math)
midTerm
  
str(midTerm)      # 구조 
table(midTerm)    # 요약 
class(midTerm)    # 데이터의 타입
typeof(midTerm)   # 데이터의 타입(상세) 

View(midTerm)

##########################################################################################

# 2. 직접 데이터프레임을 만들어보자
lastTerm <- data.frame(name2 = c("song", "kim", "park"), eng2 = c(100, 50, 80), math2 = c(50, 60, 90))

View(lastTerm)
lastTerm$name2
lastTerm$eng2

str(lastTerm$name2)
str(lastTerm$eng2)
table(lastTerm$eng2)

#

test <- c("apple","banana", "kiwi", "apple", "banana", "apple")
table(test)


mean(lastTerm$eng2)
mean(lastTerm$math2)

midTerm2 <- read.csv("D:/DKCHOI R/day02/midTest2.csv")
View(midTerm2)
str(midTerm2)


library("readxl")
midTerm3 <- read_excel("D:/DKCHOI R/day02/midTest3.xlsx", sheet = 2)
View(midTerm3)

str(midTerm3)

rm(midTerm3)  # 변수 삭제 
ls()  # 변수들의 리스트 
list <- ls() 
class(list)
rm(ls())
rm(list = ls())

ls()

######################################################################################################

midTerm3
midTerm3$name

subMidTerm <- data.frame(midTerm3$name, midTerm3$tel)

subMidTerm2 <- data.frame(name2 = midTerm3$name, tel2 = midTerm3$tel)

subMidTerm2
write.csv(subMidTerm2, file = "subMidTerm2.csv")


subMidTerm2$age2 <- c(20, 30, 40)

subMidTerm2


# <- 할당연산자 = 알트 + -
addr <- c("서울", "부산", "경기도") 

subMidTerm2$addr <- addr

subMidTerm2

names(subMidTerm2)

subMidTerm2[1]     #  컬럼확인/열 추출(name2): 이름을 $함꼐 지정 또는 인덱스를 통해 갖고올수있음(조건 체크)   = subMidTerm2[, 1]
subMidTerm2[1, ]    #  행 추출 
subMidTerm2[1, 1]    # 열과 행의 접점 추출 
subMidTerm2[1, 4]
subMidTerm2[3, 1]    # 40 추출
subMidTerm2[3, 3]    # moon 추출


# 행, 열 삭제 
subMidTerm2[, -1]   # 열 삭제 
subMidTerm3 <- subMidTerm2[, -1]
subMidTerm3
subMidTerm2
subMidTerm4 <- subMidTerm2[-1, ]   # 행 삭제 
subMidTerm4
subMidTerm5 <- subMidTerm2[, -c(2:4)]    # :(콜론) = ~부터 ~까지, 여러열 삭제 
subMidTerm5

subMidTerm6 <- subMidTerm2[, -c(1,3)]    # , 선택적으로 사용할때 쉽표를 씀 
subMidTerm6

# temp1 => 1 ~ 100
temp1 <- c(1:100)
temp1

# temp2 => 1 ~ 10까지 1,3,5,7,9 
temp2 <- c(1, 3, 5, 7, 9)
temp2








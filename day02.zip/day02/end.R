a <- 100
b <- 200 
c <- 300 
print(a == b) # 비교의 결과는 참True/거짓False
print(a == c)

if(a != b){ # 제어문 안에 조건이 True 일 때만 실행됨
  print("두수가 달라요.");
  print("끝....")
}  #if-close 중괄호 주석을달아서 표시   
# 괄호 => (:open, ): close
# ()소괄호: 함수, 조건 
# {}중괄호: 포함
# []대괄호: 인덱스, 리스트 


######################################################################

# 순차적 실행 기본 
# 조건문(조건의 따라서 다르게 처리해야하는 경우) 
# 반복문(여러번 반복해서 처리해야하는 경우)

i <- 2 
if(i < 5) { 
  print("5보다 작아요...")
}else{
  print("5보다 커요...")
}


i2 <- "빅데이터" 
if(i2 == "빅데이터") { 
  print("빅데이터반이 맞군요.")
}else if(i2 == "파이썬"){
  print("파이썬반이시군요.")
}else{
  print("아무 반도 아니군요.")
}

# 변수 = 사과 
# 사과이면 제철이군요. 
# 배이면 설에 먹어요. 
# 키위이면 수입이에요. 
# 아무것도 아니면 과일이 아닌가봐요. 

var <- "사과"
if(var == "사과") {
  print("제철이군요.")
} else if(var == "배") {
  print("설에 먹어요.")
} else if(var == "키위") {
  print("수입이에요.")
} else {
  print("과일이 아닌가봐요.")
}

install.packages("lubridate")
library(lubridate)

date <- now()
date

year(date)
month(date)
day(date)
wday(date, label = T)   # 1일 일요일 

hour(date)
minute(date)
second(date)

# 11시 전이면 굿모닝 
# 15시 전이면 굿에프터눈 
# 20시 전이면 굿이브닝 
# 기타이면 굿나잇 

# date + minutes(10)  #date에 10분을 더한 날짜와 시각


date <- "인사말"
if(date >= "11시") {
  print("굿모닝"){
else if(date >= "15시") {
  print("굿에프터눈") {
else if(date >= "20시") {
  print("굿이브닝") {
else {
  print("굿나잇")
}

    
###########################################################
    
    
# 입력받은 값 판별 
input <- scan(what="")

if(input == "100점"){
  print("만점입니다.")
}else{
  print("다음 기회에")
}    

#################################################

# 삼항 연산자 
temp3 <- 80
result <- ifelse(temp3 >= 80, "통과", "불통")
result

#################################################

#반복문 
temp4 <- 10 
while(temp4 > 7){
  print("7보다 크군.")
  temp4 <- temp4 - 1
  }
  
temp5 <- c(1:5)
for(temp6   in temp5){
  print(temp6)
}
 
name <- c("김아무개", "박아무개", "송아무개", "정아무개")
for(temp8 in name){
  cat("당신의 이름은 " , temp8 , "이군요.\n")
}

student <- data.frame(name2 = name, 
                      age2 = c(30, 50, 15, 45)
                      ) 
student

for(temp9 in student$name2){
  print(temp9)
}

while(TRUE){
  input2 <- scan()
  print(input2)
  if(input2 == 0){
    print("종료합니다.")
    break
  }
}
  



  